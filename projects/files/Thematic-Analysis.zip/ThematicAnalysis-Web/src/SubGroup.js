class SubGroup {
  constructor(name) {
    this.name = name;
  }

  // To string method for SubGroup
  toString() {
    return `SubGroup: ${this.name}`;
  }
}
