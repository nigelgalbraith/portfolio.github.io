class Factor {
  constructor(name) {
    this.name = name;
  }

  // To string method for Factor
  toString() {
    return `Factor: ${this.name}`;
  }
}
