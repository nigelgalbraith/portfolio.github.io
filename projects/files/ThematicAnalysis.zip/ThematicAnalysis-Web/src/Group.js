class Group {
  constructor(name) {
    this.name = name;
  }

  // To string method for Group
  toString() {
    return `Group: ${this.name}`;
  }
}
