class Extract {
  constructor(description, example) {
    this.description = description;
  }

  // Extract to string method
  toString() {
    return `Extract: ${this.description}`;
  }
}
